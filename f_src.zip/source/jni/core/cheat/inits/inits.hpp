#pragma once

#include <unistd.h>

#include "core/memory/memory.hpp"
#include "core/cheat/hooks/dobby/dobby.h"
#include "core/cheat/hooks/hooks.hpp"

void cheat();