#pragma once 

#include "core/visuals/menu/style/style.hpp"

namespace gui {
    void render_menu ();
    void draw_open_button();
};