#pragma once

#include <vector>

inline std::vector <void*> Players;
inline std::vector <void*> Grenades;

bool find_players (void*);
bool find_grenades (void*);